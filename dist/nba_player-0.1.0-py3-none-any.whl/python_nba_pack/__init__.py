from . import player_stats
name = "nba_player"
