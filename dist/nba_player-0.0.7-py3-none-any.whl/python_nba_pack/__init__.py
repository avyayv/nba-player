from . import player_stats
from player_stats import AllOfBasketball
name = "nba_player"
